/*--------------------------------------------------------------------
 * This file is needed to autogenerate from pfnet_config.h
 * during the cmake configuration.
 * Make changes to the original file pfnet_config.cmake.in only.
 * The checks should be the similar to the autoconf configure.ac file.
 *-------------------------------------------------------------------*/
#ifndef _PFNET_CONFIG_HEADER_GUARD_H_
#define _PFNET_CONFIG_HEADER_GUARD_H_

/* Define Autoconfig default info from CMakeLists.txt */

/* Name of package */
#define PACKAGE "pfnet"

/* Version number of package */
#define VERSION "1.3.4"

/* Define to the full name of this package. */
#define PACKAGE_NAME "PFNET"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.3.4"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "PFNET 1.3.4"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "ttinoco5687@gmail.com"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "pfnet"

/* Define to the home page for this package. */
#define PACKAGE_URL "https://github.com/ttinoco/PFNET"

/* Define to 1 if <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if <stdef.h> header file. */
#define HAVE_STDDEF_H 1

/* Define to 1 if <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if <strings.h> header file. */
/* #undef HAVE_STRINGS_H */

/* Define to 1 if you have INTTYPES header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have MALLOC function. */
#define HAVE_MALLOC 1

/* Define to 1 if you have MEMSET function. */
#define HAVE_MEMSET 1

/* Define to 1 if you have POW function. */
#define HAVE_POW 1

/* Define to 1 if you have SQRT function. */
#define HAVE_SQRT 1

/* Define to 1 if you have STRCHR function. */
#define HAVE_STRCHR 1

/* Define to 1 if you have STRDUP function. */
#define HAVE_STRDUP 1

/* Define to 1 if you have STRSTR function. */
#define HAVE_STRSTR 1

/* Define to 1 if you have memory.h header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have ptrdiff_t type. */
#define HAVE_PTRDIFF_T 8

/* Define to 1 if you have sys/stat.h type. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have sys/types.h type. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have unistd.h type. */
/* #undef HAVE_UNISTD_H */

/* Define to 0 if you do not have the raw-parser library. */
#define HAVE_RAW_PARSER 1

/* Define to 0 if you do not have the epc-parser library. */
#define HAVE_EPC_PARSER 1

#endif
