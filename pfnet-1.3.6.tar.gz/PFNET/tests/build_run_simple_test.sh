gcc -Wall -L"$PWD/../src" -I"$PWD/../include" -o run_simple_test run_simple_test.c -lpfnet -lm
