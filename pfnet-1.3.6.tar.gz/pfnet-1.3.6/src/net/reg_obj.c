/** @file reg_obj.c
 *  @brief This file defines routines for handling regulating objects.
 *
 * This file is part of PFNET.
 *
 * Copyright (c) 2015, Tomas Tinoco De Rubira.
 *
 * PFNET is released under the BSD 2-clause license.
 */

#include <pfnet/reg_obj.h>

void REG_OBJ_next(char* obj_type, void** obj, Bus* bus) {

  // Gen
  if (*obj_type == OBJ_GEN) {
    if (*obj && GEN_get_reg_next((Gen*)(*obj)))
      *obj = GEN_get_reg_next((Gen*)(*obj));
    else
      *obj = NULL;
    if (!(*obj)) { // Continue with VSC
      *obj_type = OBJ_CONVVSC;
      if (BUS_get_reg_vsc_conv(bus))
        *obj = BUS_get_reg_vsc_conv(bus);
    }
  }

  // VSC
  else if (*obj_type == OBJ_CONVVSC) {
    if (*obj && CONVVSC_get_reg_next((ConvVSC*)(*obj)))
      *obj = CONVVSC_get_reg_next((ConvVSC*)(*obj));
    else
      *obj = NULL;
    if (!(*obj)) { // Continue with FACTS
      *obj_type = OBJ_FACTS;
      if (BUS_get_reg_facts(bus))
        *obj = BUS_get_reg_facts(bus);
    }
  }

  // FACTS
  else if (*obj_type == OBJ_FACTS) {
    if (*obj && FACTS_get_reg_next((Facts*)(*obj)))
      *obj = FACTS_get_reg_next((Facts*)(*obj));
    else
      *obj = NULL;
  }

  // Unknown
  else {
    *obj = NULL;
    *obj_type = OBJ_UNKNOWN;
  }
}

void OBJ_next(char* obj_type, void** obj, Bus* bus) {

  // Gen
  if (*obj_type == OBJ_GEN) {
    if (*obj && GEN_get_next((Gen*)(*obj))) {
      *obj = GEN_get_next((Gen*)(*obj));
    }
    else {
      if (BUS_get_vsc_conv(bus)) {
        *obj_type = OBJ_CONVVSC;         // Continue with VSC
        *obj = BUS_get_reg_vsc_conv(bus);
      }
      else if (BUS_get_facts_k(bus)) {
        *obj_type = OBJ_FACTS;           // Continue with FACTS
        *obj = BUS_get_facts_k(bus);
      }
      else {
        *obj = NULL;           // Terminate if there are no VSC or FACTS at the bus
      }
    }
  }

  // VSC
  else if (*obj_type == OBJ_CONVVSC) {
    if (*obj && CONVVSC_get_next_ac((ConvVSC*)(*obj))) {
      *obj = CONVVSC_get_next_ac((ConvVSC*)(*obj));
    }
    else {
      if (BUS_get_facts_k(bus)) {
        *obj_type = OBJ_FACTS;           // Continue with FACTS
        *obj = BUS_get_facts_k(bus);
      }
      else {
        *obj = NULL;           // Terminate if there are FACTS at the bus
      }
    }
  }

  // FACTS
  else if (*obj_type == OBJ_FACTS) {
    if (*obj && FACTS_get_next_k((Facts*)(*obj)))
      *obj = FACTS_get_next_k((Facts*)(*obj));
    else
      *obj = NULL;
  }

  // Unknown
  else {
    *obj = NULL;
    *obj_type = OBJ_UNKNOWN;
  }
}

void REG_OBJ_init(char* obj_type, void** obj, Bus* bus) {

  *obj_type = OBJ_GEN;
  if (BUS_get_reg_gen(bus))
    *obj = BUS_get_reg_gen(bus);
  else
    *obj = NULL;

  if (!(*obj)) {
    *obj_type = OBJ_CONVVSC;
    if (BUS_get_reg_vsc_conv(bus))
      *obj = BUS_get_reg_vsc_conv(bus);
  }

  if (!(*obj)) {
    *obj_type = OBJ_FACTS;
    if (BUS_get_reg_facts(bus))
      *obj = BUS_get_reg_facts(bus);
  }
}

void OBJ_init(char* obj_type, void** obj, Bus* bus) {

  // Gen
  *obj_type = OBJ_GEN;
  if (BUS_get_gen(bus))
    *obj = BUS_get_gen(bus);
  else
    *obj = NULL;

  // VSC
  if (!(*obj)) {
    *obj_type = OBJ_CONVVSC;
    if (BUS_get_vsc_conv(bus))
      *obj = BUS_get_vsc_conv(bus);
  }

  // FACTS
  if (!(*obj)) {
    *obj_type = OBJ_FACTS;
    if (BUS_get_facts_k(bus))
      *obj = BUS_get_facts_k(bus);
  }
}

void REG_OBJ_disable(char obj_type, void* obj) {

  // Check
  if (!obj)
    return;

  // Gen
  if (obj_type == OBJ_GEN)
    GEN_set_reg_bus((Gen*)obj,NULL);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    CONVVSC_set_reg_bus((ConvVSC*)obj,NULL);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    FACTS_set_reg_bus((Facts*)obj,NULL);
}

void REG_OBJ_set_Q(char obj_type, void* obj, REAL Q, int t) {

  // Check
  if (!obj)
    return;

  // Gen
  if (obj_type == OBJ_GEN)
    GEN_set_Q((Gen*)obj,Q,t);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    CONVVSC_set_Q((ConvVSC*)obj,Q,t);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    FACTS_set_Q_sh((Facts*)obj,Q,t);
}

void REG_OBJ_set_Q_par(char obj_type, void* obj, REAL Q_par) {

  // Check
  if (!obj)
    return;

  // Gen
  if (obj_type == OBJ_GEN)
    GEN_set_Q_par((Gen*)obj,Q_par);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    CONVVSC_set_Q_par((ConvVSC*)obj,Q_par);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    FACTS_set_Q_par((Facts*)obj,Q_par);
}

void REG_OBJ_show(char obj_type, void* obj) {

  // Check
  if (!obj)
    return;

  // Gen
  if (obj_type == OBJ_GEN)
    printf("GEN %d\n", GEN_get_index((Gen*)obj));

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    printf("CONVVSC %d\n", CONVVSC_get_index((ConvVSC*)obj));

  // FACTS
  else if (obj_type == OBJ_FACTS)
    printf("FACTS %d\n", FACTS_get_index((Facts*)obj));

  // Unknown
  else
    printf("UNKNOWN\n");
}

Bus* REG_OBJ_get_bus(char obj_type, void* obj) {

  // Check
  if (!obj)
    return NULL;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_get_bus((Gen*)obj);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_get_ac_bus((ConvVSC*)obj);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_get_bus_k((Facts*)obj);

  else
    return NULL;
}

int REG_OBJ_get_index_Q(char obj_type, void* obj, int t) {

  // Check
  if (!obj)
    return -1;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_get_index_Q((Gen*)obj,t);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_get_index_Q((ConvVSC*)obj,t);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_get_index_Q_sh((Facts*)obj,t);

  else
    return -1;
}

int REG_OBJ_get_index_P(char obj_type, void* obj, int t) {

  // Check
  if (!obj)
    return -1;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_get_index_P((Gen*)obj,t);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_get_index_P((ConvVSC*)obj,t);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_get_index_P_dc((Facts*)obj,t);

  else
    return -1;
}

REAL REG_OBJ_get_Q(char obj_type, void* obj, int t) {

  // Check
  if (!obj)
    return 0.;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_get_Q((Gen*)obj,t);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_get_Q((ConvVSC*)obj,t);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_get_Q_sh((Facts*)obj,t);

  else
    return 0.;
}

REAL REG_OBJ_get_P(char obj_type, void* obj, int t) {

  // Check
  if (!obj)
    return 0.;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_get_P((Gen*)obj,t);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_get_P((ConvVSC*)obj,t);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_get_P_dc((Facts*)obj,t);

  else
    return 0.;
}

REAL REG_OBJ_get_Q_max(char obj_type, void* obj) {

  // Check
  if (!obj)
    return 0.;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_get_Q_max((Gen*)obj);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_get_Q_max((ConvVSC*)obj);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_get_Q_max_sh((Facts*)obj);

  else
    return 0.;
}

REAL REG_OBJ_get_Q_min(char obj_type, void* obj) {

  // Check
  if (!obj)
    return 0.;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_get_Q_min((Gen*)obj);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_get_Q_min((ConvVSC*)obj);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_get_Q_min_sh((Facts*)obj);

  else
    return 0.;
}

REAL REG_OBJ_get_mva_base(char obj_type, void* obj) {

  // Check
  if (!obj)
    return 0.;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_get_mva_base((Gen*)obj);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_get_P_max((ConvVSC*)obj);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_get_P_max_dc((Facts*)obj);

  else
    return 0.;
}

REAL REG_OBJ_get_rmpct(char obj_type, void* obj) {

  // Check
  if (!obj)
    return 0.;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_get_rmpct((Gen*)obj);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_get_rmpct((ConvVSC*)obj);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_get_rmpct((Facts*)obj);

  else {
    return 0.;
  }
}

REAL REG_OBJ_get_Q_par(char obj_type, void* obj) {

  // Check
  if (!obj)
    return 0.;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_get_Q_par((Gen*)obj);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_get_Q_par((ConvVSC*)obj);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_get_Q_par((Facts*)obj);

  else
    return 0.;
}

BOOL REG_OBJ_is_in_service(char obj_type, void* obj) {

  // Check
  if (!obj)
    return FALSE;

  // Gen
  if (obj_type == OBJ_GEN)
    return GEN_is_in_service((Gen*)obj);

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return CONVVSC_is_in_service((ConvVSC*)obj);

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return FACTS_is_in_service((Facts*)obj);

  else
    return FALSE;
}

BOOL REG_OBJ_is_candidate(char obj_type, void* obj) {

  // Check
  if (!obj)
    return FALSE;

  // Gen
  if (obj_type == OBJ_GEN)
    return (GEN_has_flags((Gen*)obj,FLAG_VARS,GEN_VAR_Q) &&
            GEN_is_in_service((Gen*)obj));

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return (CONVVSC_has_flags((ConvVSC*)obj,FLAG_VARS,CONVVSC_VAR_Q) &&
            CONVVSC_is_in_service((ConvVSC*)obj));

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return (FACTS_has_flags((Facts*)obj,FLAG_VARS,FACTS_VAR_Q) &&
            FACTS_is_in_service((Facts*)obj));

  else
    return FALSE;
}

int REG_OBJ_count_candidates(Bus* bus) {
  char obj_type;
  void* obj;
  int num = 0;
  for(REG_OBJ_init(&obj_type,&obj,bus); obj != NULL; REG_OBJ_next(&obj_type,&obj,bus)) {
    if (REG_OBJ_is_candidate(obj_type,obj))
      num += 1;
  }
  return num;
}

BOOL REG_OBJ_is_regulator(char obj_type, void* obj) {

  // Check
  if (!obj)
    return FALSE;

  // Gen
  if (obj_type == OBJ_GEN)
    return (GEN_is_regulator((Gen*)obj) &&
            GEN_is_in_service((Gen*)obj));

  // VSC
  else if (obj_type == OBJ_CONVVSC)
    return (CONVVSC_get_Q_max((ConvVSC*)obj) > CONVVSC_get_Q_min((ConvVSC*)obj) &&
            CONVVSC_is_in_service((ConvVSC*)obj));

  // FACTS
  else if (obj_type == OBJ_FACTS)
    return (FACTS_get_Q_max_sh((Facts*)obj) > FACTS_get_Q_min_sh((Facts*)obj) &&
            FACTS_is_in_service((Facts*)obj));

  else
    return FALSE;
}
